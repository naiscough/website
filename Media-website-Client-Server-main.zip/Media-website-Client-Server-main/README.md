# Media-website-Client-Server
A website to watch list of media with operations on the media.
You can add a new media, delete media from the list, update media, add actor and watch actors list.
The media arrenged in a table, where the user can sort the table by rating, name or relase date

========

The server side written in Node.js.The data is written to json file that function as a databse


The client side written in html, css, js with jQurey, sweet alert and bootstarp libraries
